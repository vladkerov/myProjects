//
//  ViewController.swift
//  TestMatrixSB
//
//  Created by Vlad Kerov on 11.03.2021.
//

import UIKit

class ViewController: UIViewController {
    let matrix1 = [[1,2,3,4,5,6,7,8,9,10], [1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],
                   [1,2,3,4,5,6,7,8,9,10],
                   [1,2,3,4,5,6,7,8,9,10],
                   [1,2,3,4,5,6,7,8,9,10],]

    let matrix2 = [[1,2,3,4,5,6,7,8,9,10], [1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],
                   [1,2,3,4,5,6,7,8,9,10],
                   [1,2,3,4,5,6,7,8,9,10],
                   [1,2,3,4,5,6,7,8,9,10],]

    var resultMatrix = [Int]()
    let queue = DispatchQueue(label: "com.queue", attributes: .concurrent)

    func matrixMultiply (matrix1:[[Int]], matrix2:[[Int]])-> [Int]  {

        let n = (matrix1[0].count)-1
        let m = (matrix1.count)-1
        let q = (matrix2[0].count)-1
    for i in 0...m {
        for j in 0...q {
            var result = 0
            for k in 0...n {
      result += (matrix1[i][k])*(matrix2[k][j])
               
            }
            self.resultMatrix.append(result)
        }
    }
     
        return resultMatrix
    }
    
//    func matrixTransformer (matrix: [Int])-> [[Int]]{
//        let newMatrix = [[Int]]()
//
//
//    }

    override func viewDidLoad() {
        let newMatrix = matrixMultiply(matrix1: matrix1, matrix2: matrix2)
        print(newMatrix)
        
        
        var c:[Int] = [1,2,3]
        var b:[Int] = [4,5,6]
        let z = b[1...2]
        print(z)
        var a = [[ Int]]()
        a.append(c)
        a.append(b)
        print(a)
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

